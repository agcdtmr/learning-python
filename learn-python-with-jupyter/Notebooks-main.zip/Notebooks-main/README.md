# Notebooks of Learn Python with Jupyter

In this repository, you can find all the Notebooks from the book [Learn Python with Jupyter](https://learnpythonwithjupyter.com). 

## How to download the notebooks 
Click the green button `< > Code` at the top-right of this page. Then, click `Download ZIP`

## Download notebooks translated to other languages
- Español de México: [here](https://github.com/incognia/Notebooks) by [Rodrigo Ernesto Álvarez Aguilera](https://incognia.github.io/)

## Notebook licenses:
- Code: GNU-GPL v.3
- Narrative: CC BY-NC-SA
